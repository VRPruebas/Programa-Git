/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.tuyweb.mavenproject2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yeison Vasquez 
 */
public class Mavenproject2 {

    public static void main(String[] args) {
        String usuario="root";
        String password="";
        String url="jdbc:mysql://localhost:3306/cinema2";
        Connection conexion;
        Statement statement;
        ResultSet rs; 
        
        try {
            conexion = DriverManager.getConnection(url, usuario, password);
            statement = conexion.createStatement();
            rs = statement.executeQuery("SELECT * FROM ESTUDIO");
            while(rs.next()){
                System.out.println(rs.getString("NOMBRE"));
            }
            
            //INSERTAR DATOS
            statement.execute("INSERT INTO ESTUDIO (NOMBRE) VALUES (\"CinemaFaca\");");
            System.out.println("");
            rs = statement.executeQuery("SELECT * FROM ESTUDIO");
            while(rs.next()){
                System.out.println(rs.getString("NOMBRE"));
            }
            
            // UPDATE DATOS
            
            statement.execute("UPDATE `estudio` SET `NOMBRE` = 'StudioUniversal' WHERE `estudio`.`ID_ESTUDIO` = 35;");
            System.out.println("");
            rs = statement.executeQuery("SELECT * FROM ESTUDIO");
            while(rs.next()){
                System.out.println(rs.getString("NOMBRE"));
            }
            
            // ELIMINACION DATOS
            statement.execute("DELETE FROM estudio WHERE `estudio`.`ID_ESTUDIO` = 36");
            System.out.println("");
            rs = statement.executeQuery("SELECT * FROM ESTUDIO");
            while(rs.next()){
                System.out.println(rs.getString("NOMBRE"));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mavenproject2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


 

